package com.trello.testCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.trello.pageObjects.LoginPage;

public class TC_findXYCoordinate_001 extends BaseClass {
		
	@Test
	public void loginTest() {
		driver.get(baseURL);
		LoginPage lp = new LoginPage(driver);
		lp.clickLogin();
		lp.setUserName(userName);
		lp.clickEmailLogin();
		lp.setPassword(password);
		lp.clickSubmit();
		
		if(driver.getTitle().equals("Boards|Trello"))
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
	}
	
	public void createNewBoard() {
		
		WebElement newBoard = driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/div/div/div/div[2]/div/div/div/div[3]/div/div[2]/ul/li[2]"));
		newBoard.click();
		
		WebElement boardTitle = driver.findElement(By.xpath("/html/body/div[2]/div/section/div/form/div[1]/label/input"));
		boardTitle.sendKeys("Full Creative");
		
		
		
	}

}
