package com.trello.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	WebDriver ldriver;
	
	public LoginPage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(linkText = "Log in")
	WebElement ahrefLogin;
	
	@FindBy(name = "user")
	WebElement txtUsername;
	
	@FindBy(xpath = "//*[@id=\"login\"]")
	WebElement emailLogin;
	
	@FindBy(name = "password")
	WebElement txtPassword;
	
	@FindBy(id = "login-submit")
	WebElement btnLogin;
	
	public void clickLogin() {
			
		ahrefLogin.click();
		
	}
	
	public void setUserName(String uname) {
		
		txtUsername.sendKeys(uname);
		
	}
	
	public void clickEmailLogin() {
		
		emailLogin.click();
		
	}
	
	public void setPassword(String pwd) {
		
		txtPassword.sendKeys(pwd);
		
	}
	
	public void clickSubmit() {
		
		btnLogin.click();
	}
	
}
